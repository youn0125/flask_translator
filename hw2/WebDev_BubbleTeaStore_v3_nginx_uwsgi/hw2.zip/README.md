I have a note for you regarding my bitbucket repository.

In the repository, there are two versions in my hw2 directory.

You can grade using WebDev_BubbleTeaStore_v3_nginx_uwsgi directory.

To run code

virtualenv -p python3 env
source env/bin/activate
pip install -r requirements.txt
python app.py